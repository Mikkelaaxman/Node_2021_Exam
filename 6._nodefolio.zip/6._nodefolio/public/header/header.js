/* $(window).load(function () {
    var checkvalue = window.location.pathname;
    //alert(checkvalue);
    $("a").each(function () {
        if ($(this).attr('href') == checkvalue) { $(this).addClass("active"); }
    });

}); */