
$(document).ready(function () {

    $("#submitBtn").click(function () {
        $('#emailToast').toast('show');
    });
});
