document.getElementById("footer-copyright").innerText = `Copyright © ${new Date().getFullYear()}`;
